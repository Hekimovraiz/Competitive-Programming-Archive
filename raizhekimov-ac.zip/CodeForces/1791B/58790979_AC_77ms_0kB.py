t = int(input())
for _ in range(t):
    n = int(input())
    s = input().strip()
    
    x, y = 0, 0  
    
    for move in s:
        if move == 'L':
            x -= 1
        elif move == 'R':
            x += 1
        elif move == 'U':
            y += 1
        elif move == 'D':
            y -= 1
        
        if x == 1 and y == 1:
            print("YES")
            break
    else:
        print("NO")
