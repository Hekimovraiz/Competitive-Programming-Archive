#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
#include <ext/pb_ds/hash_policy.hpp>

#define int long long
#define Lek_Raiz                  \
    ios_base::sync_with_stdio(0); \
    cin.tie(nullptr);             \
    cout.tie(nullptr)
#define all(v) v.begin(), v.end()
#define ll long long
#define str string
#define pb push_back
#define ep emplace_back

using namespace std;
using namespace __gnu_pbds;

template <typename T>
using __indexed_multiset = tree<T, null_type, less_equal<T>, rb_tree_tag, tree_order_statistics_node_update>;

template <typename T>
using __indexed_set = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;

const int sz = 2e4 + 3;

void solve()
{
    string k;
    cin >> k;
    int h = stoi(k.substr(0, 2)); 
    int min = stoi(k.substr(3, 2)); 

    string m = (h >= 12 ? "PM" : "AM");

    if (h == 0)
    {
        h = 12;
    }
    else if (h > 12)
    {
        h -= 12;
    }

    if (h < 10)
    {
        cout << "0";
    }
    cout << h << ":";

    if (min < 10)
    {
        cout << "0";
    }
    cout << min << " " << m << "\n";
}

signed main()
{
    Lek_Raiz;
    int t = 1;
    cin >> t;
    while (t--)
    {
        solve();
    }
}
