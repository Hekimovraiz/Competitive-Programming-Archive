#include <bits/stdc++.h>
#define Lek_Raiz ios_base::sync_with_stdio(0); cin.tie(nullptr); cout.tie(nullptr);
using namespace std;
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace __gnu_pbds;

template <typename T>
using __indexed_multiset = tree<T, null_type, less_equal<T>, rb_tree_tag, tree_order_statistics_node_update>;
template <typename T>
using __indexed_set = tree<T , null_type , less<T> , rb_tree_tag, tree_order_statistics_node_update>;

int main()
{
    Lek_Raiz
    string s; cin >> s;
    int k = 0 , f = 0;
    for(int i = 0 ; i < (int) s.size() ; ++i)
    {
        if(s[i] == '(')
        {
            ++k;
        }
        else if(s[i] == ')' && k > 0)
        {
            --k;
            f += 2;

        }
    }
    cout << f << "\n";
}

